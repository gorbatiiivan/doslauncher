MfPack X 3.1.0

NOTES: 
 - This release is updated for compiler version 17 up to 34.
 - SDK version 10.0.22000.0
 - Requires Windows 10 or later.

First release date: 04-06-2012
Final release date: 28-10-2021

Copyright © FactoryX. All rights reserved.

**Install notes**

1 - You don't have to Install the package, just compiling will do.
2 - Make sure you include necessary MfPack/src path in your project search path.




